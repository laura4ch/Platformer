#ifndef PLATFORM_H
#define PLATFORM_H
#include "Rabbit.h"
#include <iostream>
#include <SFML/Graphics.hpp>
class Rabbit;



class  Platform{
    public:
        Platform(int, int);



        sf::Sprite getPlatSprite (){return PlatSprite;}



        void DrawPlatf();
        void PlatWithRab(/**sf::Sprite PlatSprite,**/ sf::Sprite CharSprite,Rabbit* rabcon);



    protected:

    private:

        sf::Image PlatImage;
        sf::Texture PlatText;
        sf::Sprite PlatSprite;
};

#endif // PLATFORM_H
