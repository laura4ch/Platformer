#ifndef RABBIT_H
#define RABBIT_H
#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>
#include <iostream>
#include "Platform.h"


class Rabbit
{
    public:

    void Controls(){
       if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right)){
            x++;
            right=true;
            left=false;
            inMove=true;
                          }


        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left)){
            x--;
            right=false;
            left=true;
            inMove=true;
                          }
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){
            jump=true;
                          }

    }




        Rabbit();
        ~Rabbit();
        void DrawRabbit();
        void AnimeRabbit();
        void GetSprite();
        void RabFall();
        void setJump(bool jump){this->jump=jump;}
        int getPhase(){return this->phase;}
        int getY(){return this->y;}
        sf::Sprite getCharSprite(){return CharSprite;}
        void setInMove(bool inMove){this->inMove=inMove;}


    protected:

    private:
    bool left, right;
    bool jump;

    bool inMove;
    int SpriteNum;
    int framestate;
    int f_xy[8][12][2]; ///FRAME 1- sprite, 2 -frame, 3-xy;
    int life;
    sf::Image CharImage;
    sf::Texture CharText;
    sf::Sprite CharSprite;

    sf::Image TextImage;
    sf::Texture TextText;
    sf::Sprite TextSprite;

    sf::Image CarImage;
    sf::Texture CarText;
    sf::Sprite CarSprite;

    sf::Image ClearImage;
    sf::Texture ClearText;
    sf::Sprite ClearSprite;

    sf::Image HeartImage;
    sf::Texture HeartText;
    sf::Sprite HeartSprite;

    int x;
    double y;
    int phase;


};

#endif // RABBIT_H
