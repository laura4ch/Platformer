#ifndef MAP_H
#define MAP_H


class Map
{
    public:
        Map();
        ~Map();
        int Pasaule();

    protected:

    private:
};

#endif // MAP_H
