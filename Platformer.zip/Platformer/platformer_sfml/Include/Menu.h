#ifndef MENU_H
#define MENU_H
#include <SFML/Graphics.hpp>

class Menu
{
    public:
        Menu();
        int MenuWindow(sf::RenderWindow *window);
        ~Menu();

    protected:

    private:


};

#endif // MENU_H
