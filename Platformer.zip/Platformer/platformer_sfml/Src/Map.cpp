#include "Map.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Rabbit.h"
#include "Platform.h"

Map::Map()
{
    //ctor
}

extern sf::RenderWindow *window;

int Map::Pasaule(){

    sf::Event event;

 ///BACKGROUND
    sf::Image BackImage;
    BackImage.loadFromFile("../Images/background.jpg");
    sf::Texture BackTexture;
    BackTexture.loadFromImage(BackImage);

    sf::Sprite BackSprite;
    BackSprite.setTexture(BackTexture);
    BackSprite.setTextureRect(sf::IntRect(0,0,800,500));
    BackSprite.setPosition(0,0);

///PLATFORM




    Rabbit rabcon;
    Platform plat(100,300);
    Platform plat1(350,200);

    int life=3;
    while(window->isOpen())
    {

        window->draw(BackSprite);
        plat.DrawPlatf();
        plat1.DrawPlatf();
        sf::Sprite tempCharSprite = rabcon.getCharSprite();





        rabcon.DrawRabbit();

        plat.PlatWithRab(rabcon.getCharSprite(),&rabcon);
        plat1.PlatWithRab(rabcon.getCharSprite(),&rabcon);
        while (window->pollEvent(event))
        {

            if (event.type == sf::Event::Closed)
            {
                window->close();
            }


            rabcon.DrawRabbit();


        }

        window->display();

    }


return 0;
}








Map::~Map()
{
    //dtor
}
