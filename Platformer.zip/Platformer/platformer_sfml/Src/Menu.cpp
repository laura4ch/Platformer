#include "Menu.h"
#include <iostream>
#include <SFML/Graphics.hpp>

Menu::Menu()
{
    //ctor
}

extern sf::RenderWindow *window;


int Menu::MenuWindow(sf::RenderWindow *window)
{



    ///MENU
    sf:: Image MenuImage;
    MenuImage.loadFromFile("../Images/Menu.png");
    sf::Texture MenuTexture;
    MenuTexture.loadFromImage(MenuImage);

    sf::Sprite MenuSprite;
    MenuSprite.setTexture(MenuTexture);
    MenuSprite.setPosition(0,0);

    ///BUTTON NEW GAME
    sf::Image MenuButton;
    MenuButton.loadFromFile("../Images/Menubutton.png");

    sf::Texture MenuButtonTexture;
    MenuButtonTexture.loadFromImage(MenuButton);

    sf::Sprite MenuButtonSprite;
    MenuButtonSprite.setTexture(MenuButtonTexture);
    MenuButtonSprite.setTextureRect(sf::IntRect(0,0,150,46));
    MenuButtonSprite.setPosition(320,200);


    ///BUTTON NEW GAME PRESSED

    sf::Image MenuButtonPress;
    MenuButtonPress.loadFromFile("../Images/buttonpressNew.png");

    sf::Texture MenuButtonPressTexture;
    MenuButtonPressTexture.loadFromImage(MenuButtonPress);

    sf::Sprite MenuButtonPressSprite;
    MenuButtonPressSprite.setTexture(MenuButtonPressTexture);
    MenuButtonPressSprite.setTextureRect(sf::IntRect(0,0,150,46));
    MenuButtonPressSprite.setPosition(320,200);


    ///BUTTON EXIT
    sf::Image ExitButton;
    ExitButton.loadFromFile("../Images/Exitbutton.png");

    sf::Texture ExitButtonTexture;
    ExitButtonTexture.loadFromImage(ExitButton);

    sf::Sprite ExitButtonSprite;
    ExitButtonSprite.setTexture(ExitButtonTexture);
    ExitButtonSprite.setTextureRect(sf::IntRect(0,0,150,46));
    ExitButtonSprite.setPosition(320,380);

    ///BUTTON EXIT PRESSED
    sf::Image ExitButtonPress;
    ExitButtonPress.loadFromFile("../Images/buttonpressExit.png");

    sf::Texture ExitButtonPressTexture;
    ExitButtonPressTexture.loadFromImage(ExitButtonPress);

    sf::Sprite ExitButtonPressSprite;
    ExitButtonPressSprite.setTexture(ExitButtonPressTexture);
    ExitButtonPressSprite.setTextureRect(sf::IntRect(0,0,150,46));
    ExitButtonPressSprite.setPosition(320,380);

    bool show=true;
    bool showEx=true;
    sf::Event event;
    int i=0;


    while (window->isOpen())
    {

        while (window->pollEvent(event))
        {


            if (event.type == sf::Event::Closed){
                window->close();
            }
            if (event.type == sf::Event::KeyPressed){
                    ///MENUBUTTONPRESSED

                if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down)){
                i++;
                }
                if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)){
                i--;
                }


                        if(i>=3) i=1;

                switch (i){
                    case 1:
                        show=false;
                        window->draw(MenuButtonPressSprite);
                        showEx=true;
                          if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return)){
                                    window->clear();
                                return 1;
                          }
                        break;
                    case 2:
                        show=true;
                        showEx=false;
                        window->draw(ExitButtonPressSprite);
                        if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return)){
                            window->close();
                            return 0;
                }
                        break;}



            }

        }

        window->draw(MenuSprite);
        if (show){
            window->draw(MenuButtonSprite);
        }else{
            window->draw(MenuButtonPressSprite);
        }

        if (showEx){
            window->draw(ExitButtonSprite);
        }else{
            window->draw(ExitButtonPressSprite);
        }
        window->display();

    }


}


Menu::~Menu()
{
    //dtor
}
