#include "Rabbit.h"
#include <iostream>
#include <SFML/Graphics.hpp>
extern sf::RenderWindow *window;


Rabbit::Rabbit()
{
    life=3;
    x=200;
    y=300;
    jump=false;
    right=true;
    left=false;
    framestate=0;
    SpriteNum=7;
    phase = 0;
    inMove=false;

    AnimeRabbit();

    CharImage.loadFromFile("../Images/rabsprite.png");
    CharImage.createMaskFromColor(sf::Color(120,195,128,255));

    CharText.loadFromImage(CharImage);

    CharSprite.setTexture(CharText);

    CharSprite.setTextureRect(sf::IntRect(f_xy[SpriteNum][4][0],f_xy[SpriteNum][4][1],32,32));


}
    ///ANIMACIJA
void Rabbit::GetSprite()
{
    if(inMove)
    {
        if(right)
        {
            switch(framestate)
            {
                case 0:
                    CharSprite.setTextureRect(sf::IntRect(f_xy[SpriteNum][6][0],f_xy[SpriteNum][6][1],32,32));
                    framestate++;
                    break;
                case 1:
                    CharSprite.setTextureRect(sf::IntRect(f_xy[SpriteNum][7][0],f_xy[SpriteNum][7][1],32,32));
                    framestate++;
                    break;
                 case 2:
                    CharSprite.setTextureRect(sf::IntRect(f_xy[SpriteNum][8][0],f_xy[SpriteNum][8][1],32,32));
                    framestate=0;
                    break;
            }
        }

        if(left)
        {
            switch(framestate)
            {
                case 0:
                    CharSprite.setTextureRect(sf::IntRect(f_xy[SpriteNum][3][0],f_xy[SpriteNum][3][1],32,32));
                    framestate++;
                    break;
                case 1:
                    CharSprite.setTextureRect(sf::IntRect(f_xy[SpriteNum][4][0],f_xy[SpriteNum][4][1],32,32));
                    framestate++;
                    break;
                 case 2:
                    CharSprite.setTextureRect(sf::IntRect(f_xy[SpriteNum][5][0],f_xy[SpriteNum][5][1],32,32));
                    framestate=0;
                    break;
            }
        }
    }

}


void Rabbit::DrawRabbit()
{

    inMove=false;
    if(jump){
        if(phase>=0 && phase<100)
        {
            y-=1;
            phase++;
        }
        else
        {
            if(phase>=100 )
            {
                jump = false;
                phase =0 ;

            }
        }

           //
    }
    /// /// /// /// /// ////////////////////////////////////////////////////////////////// /// /// /// /// ///
    CharSprite.setPosition(x,y);
    Controls();
    GetSprite();
    window->draw(CharSprite);

    TextImage.loadFromFile("../Images/life.png");
    TextImage.createMaskFromColor(sf::Color(255,255,255,255));
    TextText.loadFromImage(TextImage);
    TextSprite.setTexture(TextText);
    TextSprite.setScale(0.4f,0.4f);
    TextSprite.setPosition(650,0);
    window->draw(TextSprite);

    CarImage.loadFromFile("../Images/carrot.png");
    CarImage.createMaskFromColor(sf::Color(255,255,255,255));
    CarText.loadFromImage(CarImage);
    CarSprite.setTexture(CarText);
    CarSprite.setPosition(650,100);
    CarSprite.setScale(0.1f,0.1f);


    HeartImage.loadFromFile("../Images/Heart.png");
    HeartText.loadFromImage(HeartImage);
    HeartSprite.setTexture(HeartText);
    HeartSprite.setPosition(450,350);
HeartSprite.setScale(0.05f,0.05f);



    window->draw(CarSprite);

if(x>=650 && x<=680 && y>=100 && 130){

    window->clear();

    ClearImage.loadFromFile("../Images/clear.png");
    ClearText.loadFromImage(ClearImage);
    ClearSprite.setTexture(ClearText);
    ClearSprite.setTextureRect(sf::IntRect(0,0,1279,720));
    ClearSprite.setPosition(0,0);
    ClearSprite.setScale(0.62f,0.69f);

    x=650;
    y=100;
    window->draw(ClearSprite);
    CharSprite.setPosition(400,350);
    CharSprite.setScale(2.0f,2.0f);
    window->draw(CharSprite);
    window->draw(HeartSprite);
    CarSprite.setPosition(490,370);
    CarSprite.setTexture(CarText);
    //CarSprite.setScale(2.0f,2.0f);
    window->draw(CarSprite);
}


///LIFE
    if(y>=500)
    {
        life--;
        y=290;
        x=200;
    }

    if (life==0){ window->close();}

    for(int i = 0; i<life;i++){
        CarSprite.setPosition(700+30*i,0);
        window->draw(CarSprite);
    }

    if (CharSprite.getPosition().x==1 && CharSprite.getPosition().y==1 ){
        x+=5;
        y+=5;
                }
    if (CharSprite.getPosition().y<=5){
        y+=5;
                }

    if(CharSprite.getPosition().x<=5 ){
        x+=5;
                }

    if (CharSprite.getPosition().x>=750){
        x-=5;
                }
}
     /// /// /// /// /// ////////////////////////////////////////////////////////////////// /// /// /// /// ///

     void Rabbit::RabFall(){
         if(!jump){
         y+=1;
         }
     }


void Rabbit::AnimeRabbit()
{
    for(int SpriteNumber=0;SpriteNumber<8;SpriteNumber++)
    {
        for(int FrameNumber=0;FrameNumber<12;FrameNumber++)
        {
            f_xy[SpriteNumber][FrameNumber][0] = (FrameNumber*32)%(32*3) + (SpriteNumber*32*3)%(32*4*3);
            f_xy[SpriteNumber][FrameNumber][1] = FrameNumber/3*32+ (SpriteNumber/4)*32*4;
            //std::cout<<(FrameNumber*32)%(32*3) + (SpriteNumber*32*3)%(32*4*3)<<" ";
            //std::cout<<FrameNumber/3*32 + (SpriteNumber/4)*32*4<<std::endl;
        }
    }



}

Rabbit::~Rabbit()
{
    //dtor
}
