#include "Platform.h"
#include "Rabbit.h"
#include <SFML/Graphics.hpp>

extern sf::RenderWindow *window;

Platform::Platform(int x, int y)
{
        PlatImage.loadFromFile("../Images/platforms.png");

        PlatText.loadFromImage(PlatImage);


        PlatSprite.setTexture(PlatText);
        PlatSprite.setTextureRect(sf::IntRect(0,0,1000,150));
        PlatSprite.setPosition(x,y);
        PlatSprite.setScale(0.25f,0.25f);

}



void Platform::PlatWithRab(/**sf::Sprite PlatSprite,**/ sf::Sprite CharSprite,Rabbit* rabcon){

    int CharX = CharSprite.getPosition().x;
    int CharY = CharSprite.getPosition().y;
    int PlatY = PlatSprite.getPosition().y;
    int PlatX = PlatSprite.getPosition().x;

    if (CharY==PlatY && CharX>=PlatX && CharX<=PlatX+250|| CharY==PlatY+100 && CharX>=PlatX-250 && CharX<=PlatX-30)
    {

    }
    else if(CharY==PlatY-100 && CharX>=PlatX+250 && CharX<=PlatX+470){
    }

    else{
        //std::cout<<0;
    rabcon->RabFall();
    }

}



void Platform::DrawPlatf(){

    int x=PlatSprite.getPosition().x;
    int y=PlatSprite.getPosition().y;
    PlatSprite.setPosition(x,y+32);
    window->draw(PlatSprite);
    PlatSprite.setPosition(x,y);

    }


