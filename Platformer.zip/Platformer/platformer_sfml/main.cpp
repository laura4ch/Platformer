#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <iostream>
#include "Menu.h"
#include "Rabbit.h"
#include "Map.h"

extern sf::RenderWindow *window;
sf::RenderWindow *window;



int main(){
    sf::Clock clock;
    float time=0;
    window = new sf::RenderWindow (sf::VideoMode(800,500),"GAME");
    Menu menuWin;
    Map mapmap;
    if( menuWin.MenuWindow(window)==1)
    {
        mapmap.Pasaule();

    }


time=clock.restart().asMicroseconds();
time=time/3000;
std::cout<<time;

    delete window;

return 0;
}
